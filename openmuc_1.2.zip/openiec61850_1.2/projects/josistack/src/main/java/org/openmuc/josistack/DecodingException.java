/*
 * Copyright 2011-16 Fraunhofer ISE, energy & meteo Systems GmbH and other contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package org.openmuc.josistack;

public final class DecodingException extends Exception {

    private static final long serialVersionUID = -4102153710148894434L;

    public DecodingException() {
        super();
    }

    public DecodingException(String s) {
        super(s);
    }

    public DecodingException(Throwable cause) {
        super(cause);
    }

    public DecodingException(String s, Throwable cause) {
        super(s, cause);
    }

}
