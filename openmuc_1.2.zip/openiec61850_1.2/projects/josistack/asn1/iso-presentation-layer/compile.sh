rm ../../src/main/java-gen/org/openmuc/josistack/internal/presentation/asn1/*.java
jasn1-compiler.sh -o "../../src/main/java-gen/org/openmuc/josistack/internal/presentation/" -p "org.openmuc.josistack.internal.presentation" iso-presentation-layer.asn
