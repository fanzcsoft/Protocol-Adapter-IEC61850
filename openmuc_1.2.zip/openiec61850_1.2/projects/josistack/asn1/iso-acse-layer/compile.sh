rm ../../src/main/java-gen/org/openmuc/josistack/internal/acse/asn1/*
jasn1-compiler.sh -o "../../src/main/java-gen/org/openmuc/josistack/internal/acse/" -p "org.openmuc.josistack.internal.acse" iso-acse-layer.asn
