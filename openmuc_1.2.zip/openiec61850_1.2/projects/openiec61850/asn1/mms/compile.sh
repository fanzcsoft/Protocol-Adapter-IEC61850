#!/bin/sh

rm ../../src/main/java-gen/org/openmuc/openiec61850/internal/mms/asn1/*

jasn1-compiler.sh -o "../../src/main/java-gen/org/openmuc/openiec61850/internal/mms/" -p "org.openmuc.openiec61850.internal.mms" mms.asn
