/*
 * Copyright 2011-16 Fraunhofer ISE, energy & meteo Systems GmbH and other contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package org.openmuc.openiec61850;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openmuc.openiec61850.internal.mms.asn1.ConfirmedServiceResponse;
import org.openmuc.openiec61850.internal.mms.asn1.GetVariableAccessAttributesResponse;
import org.openmuc.openiec61850.internal.mms.asn1.TypeDescription;
import org.openmuc.openiec61850.internal.mms.asn1.TypeDescription.SubSeq_structure.SubSeqOf_components;
import org.openmuc.openiec61850.internal.mms.asn1.TypeSpecification;

final class DataDefinitionResParser {

    static LogicalNode parseGetDataDefinitionResponse(ConfirmedServiceResponse confirmedServiceResponse,
            ObjectReference lnRef) throws ServiceError {

        if (confirmedServiceResponse.getVariableAccessAttributes == null) {
            throw new ServiceError(ServiceError.FAILED_DUE_TO_COMMUNICATIONS_CONSTRAINT,
                    "decodeGetDataDefinitionResponse: Error decoding GetDataDefinitionResponsePdu");
        }

        GetVariableAccessAttributesResponse varAccAttrs = confirmedServiceResponse.getVariableAccessAttributes;
        TypeDescription typeSpec = varAccAttrs.typeDescription;
        if (typeSpec.structure == null) {
            throw new ServiceError(ServiceError.FAILED_DUE_TO_COMMUNICATIONS_CONSTRAINT,
                    "decodeGetDataDefinitionResponse: Error decoding GetDataDefinitionResponsePdu");
        }

        SubSeqOf_components structure = typeSpec.structure.components;

        List<FcDataObject> fcDataObjects = new LinkedList<FcDataObject>();

        Fc fc;
        for (TypeDescription.SubSeq_structure.SubSeqOf_components.SubSeq fcComponent : structure.seqOf) {
            if (fcComponent.componentName == null) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "Error decoding GetDataDefinitionResponsePdu");
            }

            if (fcComponent.componentType.typeDescription.structure == null) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "Error decoding GetDataDefinitionResponsePdu");
            }

            String fcString = fcComponent.componentName.toString();
            if (fcString.equals("LG") || fcString.equals("GO") || fcString.equals("GS") || fcString.equals("MS")
                    || fcString.equals("US")) {
                continue;
            }

            fc = Fc.fromString(fcComponent.componentName.toString());
            SubSeqOf_components subStructure = fcComponent.componentType.typeDescription.structure.components;

            fcDataObjects.addAll(getFcDataObjectsFromSubStructure(lnRef, fc, subStructure));

        }

        LogicalNode ln = new LogicalNode(lnRef, fcDataObjects);

        return ln;

    }

    private static List<FcDataObject> getFcDataObjectsFromSubStructure(ObjectReference lnRef, Fc fc,
            SubSeqOf_components structure) throws ServiceError {

        List<TypeDescription.SubSeq_structure.SubSeqOf_components.SubSeq> structComponents = structure.seqOf;
        List<FcDataObject> dataObjects = new ArrayList<FcDataObject>(structComponents.size());

        for (TypeDescription.SubSeq_structure.SubSeqOf_components.SubSeq doComp : structComponents) {
            if (doComp.componentName == null) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "Error decoding GetDataDefinitionResponsePdu");
            }
            if (doComp.componentType.typeDescription.structure == null) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "Error decoding GetDataDefinitionResponsePdu");
            }

            ObjectReference doRef = new ObjectReference(lnRef + "." + doComp.componentName.toString());
            List<FcModelNode> children = getDoSubModelNodesFromSubStructure(doRef, fc,
                    doComp.componentType.typeDescription.structure.components, false);
            if (fc == Fc.RP) {
                dataObjects.add(new Urcb(doRef, children));
            }
            else if (fc == Fc.BR) {
                dataObjects.add(new Brcb(doRef, children));
            }
            else {
                dataObjects.add(new FcDataObject(doRef, fc, children));
            }

        }

        return dataObjects;

    }

    private static List<FcModelNode> getDoSubModelNodesFromSubStructure(ObjectReference parentRef, Fc fc,
            SubSeqOf_components structure, boolean parentWasArray) throws ServiceError {

        Collection<TypeDescription.SubSeq_structure.SubSeqOf_components.SubSeq> structComponents = structure.seqOf;
        List<FcModelNode> dataObjects = new ArrayList<FcModelNode>(structComponents.size());

        for (TypeDescription.SubSeq_structure.SubSeqOf_components.SubSeq component : structComponents) {
            if (component.componentName == null) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "Error decoding GetDataDefinitionResponsePdu");
            }

            String childName = component.componentName.toString();
            ObjectReference childReference;
            if (!parentWasArray) {
                childReference = new ObjectReference(parentRef + "." + childName);
            }
            else {
                childReference = new ObjectReference(parentRef + childName);
            }
            dataObjects.add(getModelNodesFromTypeSpecification(childReference, fc, component.componentType, false));

        }
        return dataObjects;
    }

    private static FcModelNode getModelNodesFromTypeSpecification(ObjectReference ref, Fc fc,
            TypeSpecification mmsTypeSpec, boolean parentWasArray) throws ServiceError {

        if (mmsTypeSpec.typeDescription.array != null) {

            int numArrayElements = (int) mmsTypeSpec.typeDescription.array.numberOfElements.value;
            List<FcModelNode> arrayChildren = new ArrayList<FcModelNode>(numArrayElements);
            for (int i = 0; i < numArrayElements; i++) {
                arrayChildren.add(
                        getModelNodesFromTypeSpecification(new ObjectReference(ref + "(" + Integer.toString(i) + ")"),
                                fc, mmsTypeSpec.typeDescription.array.elementType, true));
            }

            return new Array(ref, fc, arrayChildren);

        }

        if (mmsTypeSpec.typeDescription.structure != null) {
            List<FcModelNode> children = getDoSubModelNodesFromSubStructure(ref, fc,
                    mmsTypeSpec.typeDescription.structure.components, parentWasArray);
            return (new ConstructedDataAttribute(ref, fc, children));
        }

        // it is a single element
        BasicDataAttribute bt = convertMmsBasicTypeSpec(ref, fc, mmsTypeSpec.typeDescription);
        if (bt == null) {
            throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                    "decodeGetDataDefinitionResponse: Unknown data type received " + ref);
        }
        return (bt);

    }

    private static BasicDataAttribute convertMmsBasicTypeSpec(ObjectReference ref, Fc fc, TypeDescription mmsTypeSpec)
            throws ServiceError {

        if (mmsTypeSpec.bool != null) {
            return new BdaBoolean(ref, fc, null, false, false);
        }
        if (mmsTypeSpec.bitString != null) {
            int bitStringMaxLength = Math.abs((int) mmsTypeSpec.bitString.value);

            if (bitStringMaxLength == 13) {
                return new BdaQuality(ref, fc, null, false);
            }
            else if (bitStringMaxLength == 10) {
                return new BdaOptFlds(ref);
            }
            else if (bitStringMaxLength == 6) {
                return new BdaTriggerConditions(ref);
            }
            else if (bitStringMaxLength == 2) {
                if (fc == Fc.CO) {
                    // if name == ctlVal
                    if (ref.getName().charAt(1) == 't') {
                        return new BdaTapCommand(ref, fc, null, false, false);
                    }
                    // name == Check
                    else {
                        return new BdaCheck(ref);
                    }
                }
                else {
                    return new BdaDoubleBitPos(ref, fc, null, false, false);
                }
            }
            return null;
        }
        else if (mmsTypeSpec.integer != null) {
            switch ((int) mmsTypeSpec.integer.value) {
            case 8:
                return new BdaInt8(ref, fc, null, false, false);
            case 16:
                return new BdaInt16(ref, fc, null, false, false);
            case 32:
                return new BdaInt32(ref, fc, null, false, false);
            case 64:
                return new BdaInt64(ref, fc, null, false, false);
            }
        }
        else if (mmsTypeSpec.unsigned != null) {
            switch ((int) mmsTypeSpec.unsigned.value) {
            case 8:
                return new BdaInt8U(ref, fc, null, false, false);
            case 16:
                return new BdaInt16U(ref, fc, null, false, false);
            case 32:
                return new BdaInt32U(ref, fc, null, false, false);
            }
        }
        else if (mmsTypeSpec.floatingPoint != null) {
            int floatSize = (int) mmsTypeSpec.floatingPoint.formatWidth.value;
            if (floatSize == 32) {
                return new BdaFloat32(ref, fc, null, false, false);
            }
            else if (floatSize == 64) {
                return new BdaFloat64(ref, fc, null, false, false);
            }
            throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                    "FLOAT of size: " + floatSize + " is not supported.");
        }
        else if (mmsTypeSpec.octetString != null) {
            int stringSize = (int) mmsTypeSpec.octetString.value;
            if (stringSize > 255 || stringSize < -255) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "OCTET_STRING of size: " + stringSize + " is not supported.");
            }
            return new BdaOctetString(ref, fc, null, Math.abs(stringSize), false, false);

        }
        else if (mmsTypeSpec.visibleString != null) {
            int stringSize = (int) mmsTypeSpec.visibleString.value;
            if (stringSize > 255 || stringSize < -255) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "VISIBLE_STRING of size: " + stringSize + " is not supported.");
            }
            return new BdaVisibleString(ref, fc, null, Math.abs(stringSize), false, false);
        }
        else if (mmsTypeSpec.mMSString != null) {
            int stringSize = (int) mmsTypeSpec.mMSString.value;
            if (stringSize > 255 || stringSize < -255) {
                throw new ServiceError(ServiceError.PARAMETER_VALUE_INAPPROPRIATE,
                        "UNICODE_STRING of size: " + stringSize + " is not supported.");
            }
            return new BdaUnicodeString(ref, fc, null, Math.abs(stringSize), false, false);
        }
        else if (mmsTypeSpec.utcTime != null) {
            return new BdaTimestamp(ref, fc, null, false, false);
        }
        else if (mmsTypeSpec.binaryTime != null) {
            return new BdaEntryTime(ref, fc, null, false, false);
        }
        return null;
    }
}
