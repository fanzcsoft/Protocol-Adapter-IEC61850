/*
 * Copyright 2011-16 Fraunhofer ISE, energy & meteo Systems GmbH and other contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package org.openmuc.openiec61850;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.openmuc.openiec61850.internal.mms.asn1.AlternateAccess;
import org.openmuc.openiec61850.internal.mms.asn1.AlternateAccessSelection;
import org.openmuc.openiec61850.internal.mms.asn1.AlternateAccessSelection.SubChoice_selectAccess;
import org.openmuc.openiec61850.internal.mms.asn1.AlternateAccessSelection.SubChoice_selectAccess.SubChoice_component;
import org.openmuc.openiec61850.internal.mms.asn1.BasicIdentifier;
import org.openmuc.openiec61850.internal.mms.asn1.Identifier;
import org.openmuc.openiec61850.internal.mms.asn1.ObjectName;
import org.openmuc.openiec61850.internal.mms.asn1.Unsigned32;
import org.openmuc.openiec61850.internal.mms.asn1.VariableDefs;
import org.openmuc.openiec61850.internal.mms.asn1.VariableSpecification;

public abstract class FcModelNode extends ModelNode {

    private VariableDefs.SubSeq variableDef = null;
    Fc fc;
    private ServerAssociation selected = null;
    private TimerTask task = null;

    public Fc getFc() {
        return fc;
    }

    @Override
    public String toString() {
        return getReference().toString() + " [" + fc + "]";
    }

    boolean select(ServerAssociation association, Timer timer) {
        if (selected != null) {
            if (selected != association) {
                return false;
            }
        }
        else {
            selected = association;
            association.selects.add(this);
        }

        ModelNode sboTimeoutNode = association.serverModel.findModelNode(objectReference, Fc.CF).getChild("sboTimeout");

        if (sboTimeoutNode == null) {
            return true;
        }

        long sboTimeout = ((BdaInt32U) sboTimeoutNode).getValue();

        if (sboTimeout == 0) {
            return true;
        }

        class SelectResetTask extends TimerTask {
            ServerAssociation association;

            SelectResetTask(ServerAssociation association) {
                this.association = association;
            }

            @Override
            public void run() {
                synchronized (association.serverModel) {
                    if (task == this) {
                        task = null;
                        deselectAndRemove(association);
                    }
                }
            }
        }

        if (task != null) {
            task.cancel();
        }

        task = new SelectResetTask(association);
        timer.schedule(task, sboTimeout);

        return true;

    }

    void deselectAndRemove(ServerAssociation association) {
        selected = null;
        if (task != null) {
            task.cancel();
            task = null;
        }
        association.selects.remove(this);
    }

    void deselect() {
        selected = null;
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    boolean isSelected() {
        if (selected == null) {
            return false;
        }
        return true;
    }

    boolean isSelectedBy(ServerAssociation association) {
        if (selected == association) {
            return true;
        }
        return false;
    }

    VariableDefs.SubSeq getMmsVariableDef() {

        if (variableDef != null) {
            return variableDef;
        }

        AlternateAccess alternateAccess = null;

        StringBuilder preArrayIndexItemId = new StringBuilder(objectReference.get(1));
        preArrayIndexItemId.append("$");
        preArrayIndexItemId.append(fc);

        int arrayIndexPosition = objectReference.getArrayIndexPosition();
        if (arrayIndexPosition != -1) {

            for (int i = 2; i < arrayIndexPosition; i++) {
                preArrayIndexItemId.append("$");
                preArrayIndexItemId.append(objectReference.get(i));
            }

            List<AlternateAccess.SubChoice> subSeqOfAlternateAccess = new ArrayList<AlternateAccess.SubChoice>();
            Unsigned32 indexBerInteger = new Unsigned32(Integer.parseInt(objectReference.get(arrayIndexPosition)));

            if (arrayIndexPosition < (objectReference.size() - 1)) {
                // this reference points to a sub-node of an array element

                StringBuilder postArrayIndexItemId = new StringBuilder(objectReference.get(arrayIndexPosition + 1));

                for (int i = (arrayIndexPosition + 2); i < objectReference.size(); i++) {
                    postArrayIndexItemId.append("$");
                    postArrayIndexItemId.append(objectReference.get(i));
                }

                BasicIdentifier subIndexReference = new BasicIdentifier(postArrayIndexItemId.toString().getBytes());

                AlternateAccessSelection.SubChoice_selectAccess subIndexReferenceSelectAccess = new AlternateAccessSelection.SubChoice_selectAccess();
                subIndexReferenceSelectAccess.component = new SubChoice_component(subIndexReference);

                AlternateAccessSelection subIndexReferenceAlternateAccessSelection = new AlternateAccessSelection();
                subIndexReferenceAlternateAccessSelection.selectAccess = subIndexReferenceSelectAccess;

                AlternateAccess.SubChoice subIndexReferenceAlternateAccessSubChoice = new AlternateAccess.SubChoice();
                subIndexReferenceAlternateAccessSubChoice.unnamed = subIndexReferenceAlternateAccessSelection;

                List<AlternateAccess.SubChoice> subIndexReferenceAlternateAccessSubSeqOf = new ArrayList<AlternateAccess.SubChoice>();
                subIndexReferenceAlternateAccessSubSeqOf.add(subIndexReferenceAlternateAccessSubChoice);

                AlternateAccess subIndexReferenceAlternateAccess = new AlternateAccess(
                        subIndexReferenceAlternateAccessSubSeqOf);

                // set array index:

                AlternateAccessSelection.SubSeq_selectAlternateAccess.SubChoice_accessSelection indexAccessSelectionChoice = new AlternateAccessSelection.SubSeq_selectAlternateAccess.SubChoice_accessSelection();
                indexAccessSelectionChoice.index = indexBerInteger;

                AlternateAccessSelection.SubSeq_selectAlternateAccess indexAndLowerReferenceSelectAlternateAccess = new AlternateAccessSelection.SubSeq_selectAlternateAccess();
                indexAndLowerReferenceSelectAlternateAccess.accessSelection = indexAccessSelectionChoice;
                indexAndLowerReferenceSelectAlternateAccess.alternateAccess = subIndexReferenceAlternateAccess;

                AlternateAccessSelection indexAndLowerReferenceAlternateAccessSelection = new AlternateAccessSelection();
                indexAndLowerReferenceAlternateAccessSelection.selectAlternateAccess = indexAndLowerReferenceSelectAlternateAccess;

                AlternateAccess.SubChoice indexAndLowerReferenceAlternateAccessChoice = new AlternateAccess.SubChoice();
                indexAndLowerReferenceAlternateAccessChoice.unnamed = indexAndLowerReferenceAlternateAccessSelection;

                subSeqOfAlternateAccess.add(indexAndLowerReferenceAlternateAccessChoice);

            }
            else {
                subSeqOfAlternateAccess.add(new AlternateAccess.SubChoice(new AlternateAccessSelection(null,
                        new SubChoice_selectAccess(null, indexBerInteger, null, null))));
            }

            alternateAccess = new AlternateAccess(subSeqOfAlternateAccess);

        }
        else {

            for (int i = 2; i < objectReference.size(); i++) {
                preArrayIndexItemId.append("$");
                preArrayIndexItemId.append(objectReference.get(i));
            }
        }

        ObjectName objectName = new ObjectName(null,
                new ObjectName.SubSeq_domainSpecific(new Identifier(objectReference.get(0).getBytes()),
                        new Identifier(preArrayIndexItemId.toString().getBytes())),
                null);

        VariableSpecification varSpec = new VariableSpecification(objectName);

        variableDef = new VariableDefs.SubSeq(varSpec, alternateAccess);
        return variableDef;
    }

}
