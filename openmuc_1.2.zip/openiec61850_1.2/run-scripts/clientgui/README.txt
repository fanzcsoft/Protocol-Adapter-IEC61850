
In order to run the batch files on Windows you have to rename <file_name>.bat.winfile to <file_name>.bat.
